import AnaData as AD
import os

# 处理目录下所有txt文件
for file in os.listdir("data"):
    if file.endswith(".txt"):
        result = AD.analyse_data(
            types=["ID", "Value"],
            text=os.path.join("data", file),
            REs=[r"ID:(\d+)", r"Value:(\d+\.\d+)"],
            source="local"
        )
        AD.export_data_as_excel(result, f"output_{file[:-4]}.xlsx")
