import AnaData as AD
import re

# 预编译正则表达式
patterns = [
    re.compile(r"订单号:(\w{8})"), 
    re.compile(r"金额:¥(\d+\.\d{2})"),
    re.compile(r"日期:(\d{4}-\d{2}-\d{2})")
]

# 使用预编译的正则表达式
result = AD.analyse_data(
    types=["订单号", "金额", "日期"],
    text="orders.txt",
    REs=patterns,
    source="local"
)

# 导出结果
AD.export_data_as_excel(result, "orders.xlsx")
