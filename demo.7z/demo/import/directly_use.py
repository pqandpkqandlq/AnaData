import AnaData as AD

# 从本地文件获取数据并分析
result = AD.analyse_data(
    types=["姓名", "年龄", "成绩"],  # 定义数据类型
    text="data.txt",               # 本地文件路径
    REs=[r"姓名:(\w+)", r"年龄:(\d+)", r"成绩:(\d+)"],  # 正则表达式
    source="local"                 # 数据来源
)

# 导出为Excel
AD.export_data_as_excel(result, "output.xlsx")
