import AnaData as AD

# 从网页获取数据并分析
result = AD.analyse_data(
    types=["标题", "日期", "内容"],
    text="https://example.com/news",  # 网页URL
    REs=[r"<title>(.*?)</title>", r"<time>(.*?)</time>", r"<content>(.*?)</content>"],
    source="web",                    # 数据来源
    user_agent="Mozilla/5.0"         # 自定义User-Agent
)

# 导出为TXT
AD.export_data_as_txt(result, "news.txt")
