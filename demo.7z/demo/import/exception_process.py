import AnaData as AD

try:
    result = AD.analyse_data(
        types=["Name", "Email"],
        text="invalid_data.txt",
        REs=[r"Name:(\w+)", r"Email:(\w+@\w+\.\w+)"],
        source="local"
    )
    AD.export_data_as_excel(result, "output.xlsx")
except AD.DataAnalysisError as e:
    print(f"分析错误: {e}")
except AD.ExportError as e:
    print(f"导出错误: {e}")
